/* ============================================================
   紫微斗数 App - 主入口
   水墨玄紫设计 + 八卦盘装饰
   ============================================================ */

import { useState, useEffect, lazy, Suspense } from 'react'
import { BirthForm } from '@/components/BirthForm'
import { ChartDisplay } from '@/components/chart'
import { ChartInterpretation } from '@/components/ChartInterpretation'
import { useChartStore, useAuthStore, usePointsConfigStore } from '@/stores'
import logoSvg from '@/assets/zwdsLogo.png'
import { InkBackground, BaguaDecoration, InkTextTitle, InkDivider } from '@/components/InkDecorations'

const YearlyFortune = lazy(() => import('@/components/fortune/YearlyFortune').then(m => ({ default: m.YearlyFortune })))
const LifeKLine = lazy(() => import('@/components/kline/LifeKLine').then(m => ({ default: m.LifeKLine })))
const MatchAnalysis = lazy(() => import('@/components/match/MatchAnalysis').then(m => ({ default: m.MatchAnalysis })))
const ShareCard = lazy(() => import('@/components/share/ShareCard').then(m => ({ default: m.ShareCard })))
const AuthModal = lazy(() => import('@/components/auth/AuthModal').then(m => ({ default: m.AuthModal })))
const PersonalCenter = lazy(() => import('@/components/personal/PersonalCenter').then(m => ({ default: m.PersonalCenter })))

// 全局滚动条样式 - 隐藏滚动条但保留滚动功能
const globalScrollbarStyles = `
  /* 隐藏滚动条但保持滚动功能 */
  ::-webkit-scrollbar {
    width: 0 !important;
    height: 0 !important;
    display: none;
  }

  ::-webkit-scrollbar-track {
    background: transparent;
    display: none;
  }

  ::-webkit-scrollbar-thumb {
    background: transparent;
    display: none;
  }

  /* Firefox */
  * {
    scrollbar-width: none !important;
    scrollbar-color: transparent transparent;
  }

  html, body, #root {
    overflow-x: hidden !important;
    overflow-y: auto !important;
    -ms-overflow-style: none;  /* IE and Edge */
  }
`

type TabType = 'chart' | 'fortune' | 'kline' | 'match' | 'share'

const TABS: Array<{ key: TabType; label: string; icon: string }> = [
  { key: 'chart', label: '命盘解读', icon: '☰' },
  { key: 'fortune', label: '年度运势', icon: '◎' },
  { key: 'kline', label: '人生K线', icon: '⊹' },
  { key: 'match', label: '双人合盘', icon: '⚭' },
  { key: 'share', label: '分享卡片', icon: '◈' },
]

export default function App() {
  const { chart } = useChartStore()
  const { isLoggedIn, user, setShowAuthModal, refreshUser } = useAuthStore()
  const { load: loadPointsConfig } = usePointsConfigStore()
  const [showPersonalCenter, setShowPersonalCenter] = useState(false)
  const [activeTab, setActiveTab] = useState<TabType>('chart')

  useEffect(() => {
    const token = localStorage.getItem('ziwei-token')
    if (token) {
      refreshUser()
    }
    loadPointsConfig()
  }, [])

  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <>
      {/* 固定背景兜底层 - 解决微信浏览器 body::before + background-attachment:fixed 失效问题 */}
      <div className="bg-fixed-layer" aria-hidden="true" />

      <div className={`
        flex flex-col
        min-h-screen
        pt-14 xs:pt-16 sm:pt-20 lg:pt-24
        pb-20 md:pb-0
      `}>
      {/* 全局滚动条样式 */}
      <style>{globalScrollbarStyles}</style>
      {/* 使用新背景图（已在 index.css 中设置），不再需要 InkBackground */}
      {/* <InkBackground /> */}

      {/* 头部 - 水墨玄紫毛玻璃导航（固定定位） */}
      <header
        className="
          fixed top-0 left-0 right-0 z-40
          py-2 xs:py-2.5 sm:py-4 px-3 xs:px-4 sm:px-6 lg:px-12
          bg-night/80 backdrop-blur-md
          border-b border-gold/20
        "
      >
        <div className="max-w-[1600px] mx-auto flex items-center justify-between">
          {/* Logo + 导航 */}
          <div className="flex items-center gap-6 xs:gap-8 sm:gap-10">
            {/* Logo */}
            <div className="flex items-center gap-2 xs:gap-3 sm:gap-4 flex-shrink-0">
              {/* Logo 图标 */}
              <img src={logoSvg} alt="紫微卜运 Logo" className="w-8 h-8 xs:w-10 xs:h-10 sm:w-12 sm:h-12 flex-shrink-0" />
              {/* Logo 文字 */}
              <div className="min-w-0">
                <InkTextTitle className="text-base xs:text-lg sm:text-2xl whitespace-nowrap overflow-visible">
                  紫微卜运
                </InkTextTitle>
                <p className="text-text-muted text-[10px] xs:text-xs sm:text-sm hidden sm:block truncate" style={{ fontFamily: 'var(--font-brush)' }}>
                  命理工具
                </p>
              </div>
            </div>

            {/* 桌面端导航 - 水墨风格 */}
            <nav className="hidden md:flex items-center gap-1">
              {TABS.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => handleTabChange(tab.key)}
                  className={`
                    group relative px-5 py-2.5 rounded-xl
                    text-sm font-medium transition-all duration-300
                    ink-ripple-click
                    ${activeTab === tab.key
                      ? 'text-text'
                      : 'text-text-muted hover:text-text-secondary'
                    }
                  `}>
                  {/* 背景 */}
                  <span
                    className={`
                      absolute inset-0 rounded-xl transition-all duration-300
                      ${activeTab === tab.key
                        ? 'bg-gradient-to-r from-purple-600/20 to-amber-400/10 border border-gold/30'
                        : 'group-hover:bg-purple-500/10'
                      }
                    `}
                  />
                  {/* 内容 */}
                  <span className="relative flex items-center gap-2">
                    <span className={`
                      text-base transition-all duration-300
                      ${activeTab === tab.key ? 'text-gold scale-110' : 'opacity-60 group-hover:opacity-100'}
                    `}>
                      {tab.icon}
                    </span>
                    <span style={{ fontFamily: 'var(--font-brush)' }}>{tab.label}</span>
                  </span>
                  {/* 下划线指示器 - 水墨风格 */}
                  <span
                    className={`
                      absolute -bottom-1 left-1/2 -translate-x-1/2
                      h-1 rounded-full
                      bg-gradient-to-r from-purple-400 via-amber-400 to-purple-400
                      shadow-[0_0_10px_rgba(251,191,36,0.4)]
                      transition-all duration-500
                      ${activeTab === tab.key ? 'w-3/4 opacity-100' : 'w-0 opacity-0'}
                    `}
                  />
                </button>
              ))}
            </nav>
          </div>

          {/* 个人中心 / 登录 */}
          {isLoggedIn ? (
            <button
              onClick={() => setShowPersonalCenter(true)}
              className="
                group relative
                transition-all duration-300
                ink-ripple-click
              "
              title="个人中心"
            >
              <span className="w-9 h-9 xs:w-10 xs:h-10 rounded-full bg-gradient-to-br from-star/40 to-gold/20 border border-gold/30 hover:border-gold/60 flex items-center justify-center text-base xs:text-lg overflow-hidden shadow-[0_2px_12px_rgba(0,0,0,0.3)] hover:shadow-[0_4px_16px_rgba(212,175,55,0.3)] transition-all">
                {user?.avatar_url ? (
                  <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-gold/60">🧑</span>
                )}
              </span>
            </button>
          ) : (
            <button
              onClick={() => setShowAuthModal(true)}
              className="
                group relative px-3 xs:px-4 sm:px-5 py-1.5 xs:py-2 sm:py-2.5 rounded-lg xs:rounded-xl
                bg-gradient-to-r from-gold to-gold-dark
                text-night font-semibold text-sm xs:text-base
                shadow-[0_2px_12px_rgba(212,175,55,0.25)]
                hover:shadow-[0_4px_20px_rgba(212,175,55,0.35)]
                transition-all duration-300
                ink-ripple-click
              "
              style={{ fontFamily: 'var(--font-brush)' }}
            >
              登录
            </button>
          )}
        </div>
      </header>

      {/* 移动端底部导航 - 水墨风格 */}
      <nav
        className="
          md:hidden fixed bottom-0 left-0 right-0 z-40
          px-3 xs:px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]
          bg-night/90 backdrop-blur-lg
          border-t border-gold/20
          shadow-[0_-4px_20px_rgba(0,0,0,0.3)]
        "
      >
        <div className="flex justify-around max-w-lg mx-auto w-full">
          {TABS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => handleTabChange(tab.key)}
              className={`
                flex flex-col items-center justify-center gap-1 xs:gap-1.5 px-3 py-3 rounded-xl
                transition-all duration-300
                ink-ripple-click relative flex-1 min-w-0
                ${activeTab === tab.key
                  ? 'text-gold'
                  : 'text-text-muted hover:text-text-secondary'
                }
              `}
            >
              {/* 选中背景 */}
              {activeTab === tab.key && (
                <span className="absolute inset-0 rounded-xl bg-gradient-to-t from-purple-600/25 to-transparent border border-gold/25" />
              )}
              <span className="relative text-2xl xs:text-[1.75rem] leading-none">{tab.icon}</span>
              <span className="relative text-[10px] xs:text-xs leading-tight truncate w-full text-center font-medium" style={{ fontFamily: 'var(--font-brush)' }}>{tab.label}</span>
              {/* 选中指示点 */}
              {activeTab === tab.key && (
                <span className="absolute -top-0.5 w-1.5 h-1.5 rounded-full bg-gold shadow-[0_0_8px_rgba(251,191,36,0.7)]" />
              )}
            </button>
          ))}
        </div>
      </nav>

      {/* 主内容 - 水墨玄紫风格 - 响应式滚动 */}
      <main className={`
        flex-1 px-4 xs:px-6 lg:px-12 py-4 xs:py-6 relative
        ${!chart ? 'overflow-hidden' : 'overflow-visible'}
      `}>
        {/* 装饰性八卦盘 - 背景 */}
        <div className="absolute right-12 top-12 opacity-20 pointer-events-none hidden lg:block">
          <BaguaDecoration size={180} rotate={true} />
        </div>
        <div className="absolute left-8 bottom-24 opacity-15 pointer-events-none hidden lg:block">
          <BaguaDecoration size={120} rotate={true} />
        </div>

        <div className="max-w-[1600px] mx-auto relative z-10">
          {/* 命盘解读标签 */}
          {activeTab === 'chart' && (
            !chart ? (
              <div className="flex items-center justify-center min-h-[calc(100vh-11rem)] xs:min-h-[calc(100vh-13rem)] sm:min-h-[calc(100vh-140px)] px-3 xs:px-4 py-4 xs:py-6">
                <BirthForm />
              </div>
            ) : (
              <div className="animate-fade-in space-y-4">
                {/* 命盘 */}
                <div className="w-full">
                  <ChartDisplay />
                </div>

                {/* 解读 */}
                <div className="w-full max-w-6xl mx-auto">
                  <ChartInterpretation />
                </div>

                {/* 重新排盘按钮 - 统一毛玻璃风格 */}
                <div className="text-center">
                  <button
                    onClick={() => useChartStore.getState().clear()}
                    className="
                      inline-flex items-center gap-2 px-6 py-3 rounded-xl
                      text-base font-medium
                      bg-night/60 backdrop-blur-sm
                      text-gold border border-gold/25
                      hover:bg-gold/10 hover:border-gold/50
                      hover:text-gold-light
                      transition-all duration-300
                      shadow-[0_4px_20px_rgba(0,0,0,0.2)]
                      hover:shadow-[0_4px_20px_rgba(212,175,55,0.15)]
                    "
                    style={{ fontFamily: 'var(--font-brush)' }}
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                    </svg>
                    重新输入命盘
                  </button>
                </div>
              </div>
            )
          )}

          {/* 年度运势标签 */}
          {activeTab === 'fortune' && (
            !chart ? (
              <div className="flex items-center justify-center min-h-[60vh]">
                <EmptyState message="请先在「命盘解读」中输入您的生辰信息" action={() => setActiveTab('chart')} actionLabel="前往输入" />
              </div>
            ) : (
              <Suspense fallback={<LoadingPlaceholder />}><YearlyFortune /></Suspense>
            )
          )}

          {/* 人生K线标签 */}
          {activeTab === 'kline' && (
            !chart ? (
              <div className="flex items-center justify-center min-h-[60vh]">
                <EmptyState message="请先在「命盘解读」中输入您的生辰信息" action={() => setActiveTab('chart')} actionLabel="前往输入" />
              </div>
            ) : (
              <Suspense fallback={<LoadingPlaceholder />}><LifeKLine /></Suspense>
            )
          )}

          {/* 双人合盘标签 */}
          {activeTab === 'match' && <Suspense fallback={<LoadingPlaceholder />}><MatchAnalysis /></Suspense>}

          {/* 分享卡片标签 */}
          {activeTab === 'share' && (
            !chart ? (
              <div className="flex items-center justify-center min-h-[60vh]">
                <EmptyState message="请先在「命盘解读」中输入您的生辰信息" action={() => setActiveTab('chart')} actionLabel="前往输入" />
              </div>
            ) : (
              <div className="max-w-xl mx-auto">
                <Suspense fallback={<LoadingPlaceholder />}><ShareCard /></Suspense>
              </div>
            )
          )}
        </div>
      </main>

      {/* 登录/注册弹窗 */}
      <AuthModal />

      {/* 个人中心弹窗 */}
      {showPersonalCenter && (
        <PersonalCenter onClose={() => setShowPersonalCenter(false)} />
      )}

      {/* 底部 Footer - 所有设备显示 */}
      <footer
        className="
          py-4 xs:py-5 text-center
          border-t border-white/[0.04]
          relative z-10
        "
      >
        <div className="flex items-center justify-center gap-1.5 xs:gap-2">
          <span className="text-purple-400/60 text-base xs:text-lg">☯</span>
          <p className="flex items-center gap-1.5 xs:gap-2 text-text-muted text-xs xs:text-sm" style={{ fontFamily: 'var(--font-brush)' }}>
            <span className="text-gold/60 text-xs xs:text-sm">☆</span>
            观星知势 · 谋定而行
            <span className="text-purple-400/60 text-xs xs:text-sm">☆</span>
          </p>
          <span className="text-gold/60 text-base xs:text-lg">☯</span>
        </div>
      </footer>
      </div>
    </>
  )
}

/* ------------------------------------------------------------
   空状态组件
   ------------------------------------------------------------ */

function LoadingPlaceholder() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="
        text-center p-10 rounded-2xl
        glass
        max-w-md mx-auto
        shadow-[0_8px_32px_rgba(0,0,0,0.3)]
      ">
        <span className="text-6xl mb-4 animate-pulse-soft opacity-50 block">☯</span>
        <p className="text-text-muted" style={{ fontFamily: 'var(--font-brush)' }}>加载中...</p>
      </div>
    </div>
  )
}

interface EmptyStateProps {
  message: string
  action: () => void
  actionLabel: string
}

function EmptyState({ message, action, actionLabel }: EmptyStateProps) {
  return (
    <div
      className="
        text-center p-10 rounded-2xl
        glass
        max-w-md mx-auto
        shadow-[0_8px_32px_rgba(0,0,0,0.3)]
      "
    >
      <div className="text-6xl mb-6 opacity-50 animate-pulse-soft">☯</div>
      <p className="text-text-muted mb-6 text-base" style={{ fontFamily: 'var(--font-brush)' }}>{message}</p>
      <button
        onClick={action}
        className="
          inline-flex items-center gap-2
          px-6 py-3 rounded-xl
          bg-night/60 backdrop-blur-sm
          text-gold border border-gold/25
          hover:bg-gold/10 hover:border-gold/50
          hover:text-gold-light
          transition-all duration-300
          shadow-[0_4px_20px_rgba(0,0,0,0.2)]
          hover:shadow-[0_4px_20px_rgba(212,175,55,0.15)]
          ink-ripple-click
        "
        style={{ fontFamily: 'var(--font-brush)' }}
      >
        {actionLabel}
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14 5l7 7m0 0l-7 7m7-7H3" />
        </svg>
      </button>
    </div>
  )
}
