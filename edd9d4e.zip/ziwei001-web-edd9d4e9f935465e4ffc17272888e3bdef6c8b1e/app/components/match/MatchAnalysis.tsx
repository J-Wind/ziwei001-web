/* ============================================================
   双人合盘组件
   分析两人命盘的契合度 + 追问功能
   ============================================================ */

import { useState, useCallback, useMemo, useEffect } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { useSettingsStore, useContentCacheStore, useAuthStore } from '@/stores'
import { generateChart, type BirthInfo, type Gender } from '@/lib/astro'
import { extractKnowledge, buildPromptContext } from '@/knowledge'
import { streamChat, type ChatMessage, type LLMConfig } from '@/lib/llm'
import { Button, Select } from '@/components/ui'
import { FollowUpQuestion } from '@/components/FollowUpQuestion'
import { config } from '@/config/environment'

/* ------------------------------------------------------------
   年份/月份/日期选项
   ------------------------------------------------------------ */

const currentYear = new Date().getFullYear()
const YEAR_OPTIONS = Array.from({ length: 100 }, (_, i) => ({
  value: currentYear - i,
  label: `${currentYear - i}年`,
}))
const MONTH_OPTIONS = Array.from({ length: 12 }, (_, i) => ({
  value: i + 1,
  label: `${i + 1}月`,
}))
const DAY_OPTIONS = Array.from({ length: 31 }, (_, i) => ({
  value: i + 1,
  label: `${i + 1}日`,
}))
const HOUR_OPTIONS = [
  { value: 23, label: '子时 (23:00-00:59)' },
  { value: 2, label: '丑时 (01:00-02:59)' },
  { value: 4, label: '寅时 (03:00-04:59)' },
  { value: 6, label: '卯时 (05:00-06:59)' },
  { value: 8, label: '辰时 (07:00-08:59)' },
  { value: 10, label: '巳时 (09:00-10:59)' },
  { value: 12, label: '午时 (11:00-12:59)' },
  { value: 14, label: '未时 (13:00-14:59)' },
  { value: 16, label: '申时 (15:00-16:59)' },
  { value: 18, label: '酉时 (17:00-18:59)' },
  { value: 20, label: '戌时 (19:00-20:59)' },
  { value: 22, label: '亥时 (21:00-22:59)' },
]
const GENDER_OPTIONS = [
  { value: 'male', label: '男' },
  { value: 'female', label: '女' },
]

/* ------------------------------------------------------------
   合盘提示词
   ------------------------------------------------------------ */

export const MATCH_SYSTEM_PROMPT = `# Role
你是一位擅长推演人际姻缘的紫微斗数专家。根据提供的命盘信息进行解读。在合盘分析中，你不仅观察表面的星情互补，更注重通过"飞星四化"来推演两人深层的缘分羁绊与利弊关系。

# Analysis Logic
1.  **星情对看**：分析两人命宫主星的性质是否匹配（如：强弱搭配、动静结合）。
2.  **四化互飞**：推演A的命宫四化飞入B的宫位，判断A对B是生助（化禄）还是刑克（化忌），反之亦然。
3.  **宫位参合**：观察双方夫妻宫的意象是否与对方吻合。

# Output Style Guidelines
- **使用Markdown格式**来突出重点内容：
  - **粗体** (\`**\`) 用于强调最重要的内容，如关键结论、重要提醒
  - *斜体* (\`*\`) 用于强调次要重点，如特殊说明、补充信息
  - \`代码\` (\`\`) 用于突出命理术语或特定名词
  - > 引用块 用于突出金句或重要建议
  - 列表项 用于分点说明，清晰易读

# Output Format
请严格按照以下结构输出分析报告：

## 双人命盘合参解析

### 壹· 缘分深浅
* **契合综述**：不使用分数，而是用定性描述（如：天作之合、欢喜冤家、因缘波折、相辅相成）。
* **关系本质**：从命理角度解析，两人相遇是互相成就，还是互相偿还宿债。

### 贰· 性情互动
* **相合之处**：两人性格中能够产生共鸣或互补的地方。
* **磨合难点**：两人性格中容易产生摩擦或误解的本质原因（如：一方重情，一方重利）。

### 叁· 命理羁绊（四化互飞）
* **助益分析**：分析两人在一起，谁能旺谁？（如：对方是否有助于你的事业或财运）。
* **隐忧所在**：命理上是否存在互相刑克或拖累的情况？

### 肆· 现实展望
* **未来挑战**：若长期相处或步入婚姻，最需要共同面对的现实考验是什么？
* **相处建议**：针对两人的命局特点，给出具体的相处之道与沟通建议。

---
*注：缘分天定，份在人为。合盘分析旨在增进了解，非绝对定论。*`

/* ------------------------------------------------------------
   Markdown 自定义样式组件
   ------------------------------------------------------------ */

const MarkdownComponents = {
  h1: ({ children }: { children?: React.ReactNode }) => (
    <h1 className="text-xl sm:text-2xl font-bold text-gold mt-6 mb-3 first:mt-0">{children}</h1>
  ),
  h2: ({ children }: { children?: React.ReactNode }) => (
    <h2 className="text-lg sm:text-xl font-semibold text-gold/90 mt-5 mb-2">{children}</h2>
  ),
  h3: ({ children }: { children?: React.ReactNode }) => (
    <h3 className="text-base sm:text-lg font-medium text-star-light mt-4 mb-2">{children}</h3>
  ),
  p: ({ children }: { children?: React.ReactNode }) => (
    <p className="mb-3 text-sm sm:text-base leading-relaxed">{children}</p>
  ),
  strong: ({ children }: { children?: React.ReactNode }) => (
    <strong className="text-gold font-semibold">{children}</strong>
  ),
  em: ({ children }: { children?: React.ReactNode }) => (
    <em className="text-star-light not-italic font-medium">{children}</em>
  ),
  ul: ({ children }: { children?: React.ReactNode }) => (
    <ul className="list-none space-y-1.5 mb-3 pl-4 text-sm sm:text-base">{children}</ul>
  ),
  ol: ({ children }: { children?: React.ReactNode }) => (
    <ol className="list-decimal list-inside space-y-1.5 mb-3 pl-2 text-sm sm:text-base">{children}</ol>
  ),
  li: ({ children }: { children?: React.ReactNode }) => (
    <li className="relative pl-4 before:content-['◆'] before:absolute before:left-0 before:text-star/60 before:text-xs">
      {children}
    </li>
  ),
  blockquote: ({ children }: { children?: React.ReactNode }) => (
    <blockquote className="border-l-2 border-gold/40 pl-4 my-3 italic text-text-secondary bg-gold/5 rounded-r-lg text-sm sm:text-base">
      {children}
    </blockquote>
  ),
  hr: () => (
    <hr className="my-6 border-0 h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
  ),
  code: ({ children, className }: { children?: React.ReactNode; className?: string }) => (
    className ? (
      <code className={`${className} px-2 py-0.5 rounded bg-white/10 text-star-light text-sm`}>
        {children}
      </code>
    ) : (
      <code className="px-1.5 py-0.5 rounded bg-gold/10 text-gold text-sm">{children}</code>
    )
  ),
  a: ({ children, href }: { children?: React.ReactNode; href?: string }) => (
    <a 
      href={href} 
      className="text-star-light hover:text-gold underline transition-colors"
      target="_blank" 
      rel="noopener noreferrer"
    >
      {children}
    </a>
  ),
}

/* ------------------------------------------------------------
   个人信息输入组件
   ------------------------------------------------------------ */

interface PersonInputProps {
  label: string
  value: BirthInfo
  onChange: (info: BirthInfo) => void
}

function PersonInput({ label, value, onChange }: PersonInputProps) {
  const update = (field: keyof BirthInfo, val: number | Gender) => {
    onChange({ ...value, [field]: val })
  }

  return (
    <div
      className="
        relative p-4 xs:p-6 sm:p-8
        bg-gradient-to-br from-white/[0.04] to-transparent
        backdrop-blur-xl border border-white/[0.08] rounded-xl sm:rounded-2xl
        shadow-[0_4px_20px_rgba(0,0,0,0.2)]
      "
    >
      <h3
        className="text-lg font-medium mb-4 bg-gradient-to-r from-star-light to-gold bg-clip-text text-transparent"
        style={{ fontFamily: 'var(--font-serif)' }}
      >
        {label}
      </h3>
      <div className="space-y-3">
        <div className="grid grid-cols-3 gap-2">
          <Select
            label="年"
            options={YEAR_OPTIONS}
            value={value.year}
            onChange={(e) => update('year', Number(e.target.value))}
          />
          <Select
            label="月"
            options={MONTH_OPTIONS}
            value={value.month}
            onChange={(e) => update('month', Number(e.target.value))}
          />
          <Select
            label="日"
            options={DAY_OPTIONS}
            value={value.day}
            onChange={(e) => update('day', Number(e.target.value))}
          />
        </div>
        <Select
          label="时辰"
          options={HOUR_OPTIONS}
          value={value.hour}
          onChange={(e) => update('hour', Number(e.target.value))}
        />
        <div className="flex gap-2">
          {GENDER_OPTIONS.map((opt) => (
            <label
              key={opt.value}
              className={`
                flex-1 py-2 px-3 rounded-lg text-center text-sm cursor-pointer transition-all
                ${value.gender === opt.value
                  ? 'bg-star text-white'
                  : 'bg-white/5 border border-white/10 hover:bg-white/10'
                }
              `}
            >
              <input
                type="radio"
                value={opt.value}
                checked={value.gender === opt.value}
                onChange={() => update('gender', opt.value as Gender)}
                className="sr-only"
              />
              {opt.label}
            </label>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------
   双人合盘主组件
   ------------------------------------------------------------ */

export function MatchAnalysis() {
  const { provider, enableThinking, enableWebSearch } = useSettingsStore()
  const { matchChatHistory, setMatchChatHistory } = useContentCacheStore()
  const { requireAuth } = useAuthStore()

  const [person1, setPerson1] = useState<BirthInfo>({
    year: 1990, month: 1, day: 1, hour: 12, gender: 'male',
  })
  const [person2, setPerson2] = useState<BirthInfo>({
    year: 1992, month: 6, day: 15, hour: 14, gender: 'female',
  })
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  // LLM 配置（现在不需要apiKey，后端管理）
  const llmConfig: LLMConfig = useMemo(() => ({
    provider,
    enableThinking,
    enableWebSearch,
  }), [provider, enableThinking, enableWebSearch])

  // 当有结果但没有对话历史时，初始化对话历史
  useEffect(() => {
    if (result && matchChatHistory.length === 0) {
      const chart1 = generateChart(person1)
      const chart2 = generateChart(person2)
      const knowledge1 = extractKnowledge(chart1, person1.year)
      const knowledge2 = extractKnowledge(chart2, person2.year)
      const context1 = buildPromptContext(knowledge1)
      const context2 = buildPromptContext(knowledge2)
      
      const initialUserMessage = `请分析以下两人的命盘契合度：

## 第一人
- 出生：${person1.year}年${person1.month}月${person1.day}日
- 性别：${person1.gender === 'male' ? '男' : '女'}
- 五行局：${chart1.fiveElementsClass}

${context1}

## 第二人
- 出生：${person2.year}年${person2.month}月${person2.day}日
- 性别：${person2.gender === 'male' ? '男' : '女'}
- 五行局：${chart2.fiveElementsClass}

${context2}

请分析两人的契合度和相处建议。`
      
      setMatchChatHistory([
        { role: 'user', content: initialUserMessage },
        { role: 'assistant', content: result },
      ])
    }
  }, [result, matchChatHistory, person1, person2, setMatchChatHistory])

  const handleAnalyze = useCallback(async () => {
    setLoading(true)
    setError(null)
    setResult('')

    try {
      // 生成两人命盘
      const chart1 = generateChart(person1)
      const chart2 = generateChart(person2)

      // 提取知识上下文
      const knowledge1 = extractKnowledge(chart1, person1.year)
      const knowledge2 = extractKnowledge(chart2, person2.year)
      const context1 = buildPromptContext(knowledge1)
      const context2 = buildPromptContext(knowledge2)

      const userMessage = `请分析以下两人的命盘契合度：

## 第一人
- 出生：${person1.year}年${person1.month}月${person1.day}日
- 性别：${person1.gender === 'male' ? '男' : '女'}
- 五行局：${chart1.fiveElementsClass}

${context1}

## 第二人
- 出生：${person2.year}年${person2.month}月${person2.day}日
- 性别：${person2.gender === 'male' ? '男' : '女'}
- 五行局：${chart2.fiveElementsClass}

${context2}

请分析两人的契合度和相处建议。`

      const messages: ChatMessage[] = [
        { role: 'system', content: MATCH_SYSTEM_PROMPT },
        { role: 'user', content: userMessage },
      ]

      let fullText = ''
      for await (const token of streamChat(llmConfig, messages)) {
        fullText += token
        setResult(fullText)
      }
      
      // 保存到对话历史
      setMatchChatHistory([
        { role: 'user', content: userMessage },
        { role: 'assistant', content: fullText },
      ])

      // 保存到服务器历史记录
      try {
        await fetch(`${config.apiBaseUrl}/api/user/history`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('ziwei-token')}`,
          },
          body: JSON.stringify({
            type: 'match',
            title: `双人合盘 - ${person1.gender === 'male' ? '男' : '女'}${person1.year}年 & ${person2.gender === 'male' ? '男' : '女'}${person2.year}年`,
            content: fullText,
            birth_info: { person1, person2 },
          }),
        })
      } catch {}
    } catch (err) {
      setError(err instanceof Error ? err.message : '分析失败，请重试')
    } finally {
      setLoading(false)
    }
  }, [person1, person2, llmConfig, setMatchChatHistory])

  return (
    <div className="animate-fade-in space-y-8 max-w-6xl mx-auto">
      {/* 顶部：双人信息输入 + 按钮 */}
      <div
        className="
          relative p-4 xs:p-6 sm:p-8
          bg-gradient-to-br from-white/[0.04] to-transparent
          backdrop-blur-xl border border-white/[0.08] rounded-xl sm:rounded-2xl
          shadow-[0_8px_32px_rgba(0,0,0,0.3)]
        "
      >
        {/* 顶部发光线 */}
        <div
          className="
            absolute top-0 left-1/2 -translate-x-1/2
            w-1/3 h-px
            bg-gradient-to-r from-transparent via-gold/50 to-transparent
          "
        />

        <h2
          className="
            text-xl lg:text-2xl font-semibold mb-6
            bg-gradient-to-r from-gold via-gold-light to-gold
            bg-clip-text text-transparent
          "
          style={{ fontFamily: 'var(--font-serif)' }}
        >
          双人合盘
        </h2>

        {/* 双人信息输入区 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <PersonInput label="第一人" value={person1} onChange={setPerson1} />
          <PersonInput label="第二人" value={person2} onChange={setPerson2} />
        </div>

        {/* 按钮区 */}
        <div className="flex justify-center">
          <Button
            onClick={() => requireAuth(handleAnalyze)}
            disabled={loading}
            size="md"
            variant="gold"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-night border-t-transparent rounded-full animate-spin" />
                分析中
              </span>
            ) : '开始分析合盘'}
          </Button>
        </div>

        {/* 错误提示 */}
        {error && (
          <div className="mt-4 p-3 rounded-lg bg-misfortune/10 text-misfortune text-sm border border-misfortune/20">
            {error}
          </div>
        )}
      </div>

      {/* 下方：分析结果 */}
      <div
        className="
          relative p-4 xs:p-6 sm:p-8
          bg-gradient-to-br from-white/[0.04] to-transparent
          backdrop-blur-xl border border-white/[0.08] rounded-xl sm:rounded-2xl
          shadow-[0_8px_32px_rgba(0,0,0,0.3)]
        "
      >
        {/* 顶部发光线 */}
        <div
          className="
            absolute top-0 left-1/2 -translate-x-1/2
            w-1/3 h-px
            bg-gradient-to-r from-transparent via-star/50 to-transparent
          "
        />

        {/* 未分析提示 */}
        {!result && !loading && (
          <div className="text-text-muted text-sm py-8 text-center">
            <div className="text-3xl mb-3 opacity-30">⚭</div>
            输入双方信息并点击「开始合盘分析」
          </div>
        )}

        {/* 加载中 */}
        {loading && !result && (
          <div className="flex items-center justify-center gap-3 text-text-muted py-12">
            <div className="w-5 h-5 border-2 border-star border-t-transparent rounded-full animate-spin" />
            <span>正在分析两人契合度...</span>
          </div>
        )}

        {/* 分析结果 - 书法字体 + Markdown 渲染 */}
        {result && (
          <>
            <div
              className="
                prose prose-invert max-w-none
                text-text-secondary text-sm sm:text-base leading-relaxed
              "
              style={{ fontFamily: 'var(--font-brush)' }}
            >
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={MarkdownComponents}
              >
                {result}
              </ReactMarkdown>
            </div>
            
            {/* 追问功能 */}
            <FollowUpQuestion
              systemPrompt={MATCH_SYSTEM_PROMPT}
              chatHistory={matchChatHistory}
              onChatHistoryChange={setMatchChatHistory}
              llmConfig={llmConfig}
              placeholder="基于以上合盘解读，有什么问题想问吗？"
            />
          </>
        )}
      </div>
    </div>
  )
}
